import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;

public class practice {
	private static ArrayBlockingQueue<Object> mob =  new ArrayBlockingQueue<Object>(1000);
	public static void main(String[] args) {
		addProfiles();
		proceed();
		

	}
	private static void proceed() {
	System.out.println(mob.size());
	
	for( Object  xxx: mob){
		mob.remove(xxx);
	}
	
	
	System.out.println(mob.size());
	}
	private static void addProfiles() {
		for( int x = 0 ; x<5; x++){
			mob.add(new Object());
		}
		
	}

}
