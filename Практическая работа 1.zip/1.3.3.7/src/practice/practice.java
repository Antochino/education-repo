package practice;

public class practice {
		public static void main(String args[]){
			int [] [] m={{1,2,3},{2,2,8},{3,2,2}};
		for(int row=0; row<m.length; row++){
			for(int col=0; col<m[row].length; col++){
				System.out.print(m[row][col]+"  ");
			}
		System.out.println();
		}
			
		}
	

}
